import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CreateTodo from './components/CreateTodo';
import EditTodo from './components/EditTodo';
import TodoTable from './components/TodoTable';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<TodoTable />} />
        <Route path="/create" element={<CreateTodo />} />
        <Route path="/edit/:id" element={<EditTodo />} />
      </Routes>
    </Router>
  );
};

export default App;
