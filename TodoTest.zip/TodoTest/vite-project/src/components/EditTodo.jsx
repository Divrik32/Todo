import React from 'react';
import TodoForm from './TodoForm';
import { useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';

const EditTodo = () => {
  const { id } = useParams();
  const todo = useSelector(state => state.todos.find(todo => todo.id === id));
  const navigate = useNavigate();

  const handleSuccess = () => {
    navigate('/'); 
  };

  return (
    <div>
      <TodoForm initialTodo={todo} onSuccess={handleSuccess} />
    </div>
  );
};

export default EditTodo;
