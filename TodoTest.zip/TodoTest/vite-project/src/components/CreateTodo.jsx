import React from 'react';
import TodoForm from './TodoForm';
import { useNavigate } from 'react-router-dom';

const CreateTodo = () => {
  const navigate = useNavigate();

  const handleSuccess = () => {
    navigate('/'); // Redirect to the Todo list
  };

  return (
    <div>
      <TodoForm onSuccess={handleSuccess} />
    </div>
  );
};

export default CreateTodo;
