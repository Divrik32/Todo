import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { useDispatch } from 'react-redux';
import { v4 as uuidv4 } from 'uuid';
import { addTodo, editTodo } from '../store/todosSlice';
import { TextField, Button, Box, Typography, IconButton } from '@mui/material';
import { PhotoCamera } from '@mui/icons-material';

const schema = yup.object().shape({
  title: yup.string().required('Title is required'),
  description: yup.string().required('Description is required'),
  endDate: yup.date().required('End date is required').nullable(),
  image: yup.mixed().required('Image is required'),
});

const TodoForm = ({ initialTodo, setEditingTodo, onSuccess }) => {
  const dispatch = useDispatch();
  const [imageUrl, setImageUrl] = useState(null);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  useEffect(() => {
    if (initialTodo) {
      reset(initialTodo);
      setImageUrl(initialTodo.image);
    }
  }, [initialTodo, reset]);

  const onSubmit = (data) => {
    const newTodo = {
      id: initialTodo ? initialTodo.id : uuidv4(),
      ...data,
      isCompleted: false,
      image: imageUrl,
    };

    if (initialTodo) {
      dispatch(editTodo(newTodo));
    } else {
      dispatch(addTodo(newTodo));
    }

    onSuccess();
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImageUrl(url);
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ padding: 2, borderRadius: 1, boxShadow: 3 }}>
      <Typography variant="h6" gutterBottom>
        {initialTodo ? 'Edit Todo' : 'Add Todo'}
      </Typography>
      <TextField {...register('title')} label="Title" variant="outlined" fullWidth error={!!errors.title} helperText={errors.title ? errors.title.message : ''} margin="normal" />
      <TextField {...register('description')} label="Description" variant="outlined" fullWidth error={!!errors.description} helperText={errors.description ? errors.description.message : ''} margin="normal" />
      <TextField type="date" {...register('endDate')} variant="outlined" fullWidth error={!!errors.endDate} helperText={errors.endDate ? errors.endDate.message : ''} margin="normal" InputLabelProps={{ shrink: true }} />
      <input accept="image/*" style={{ display: 'none' }} id="image-upload" type="file" {...register('image')} onChange={handleImageChange} />
      <label htmlFor="image-upload">
        <IconButton color="primary" aria-label="upload picture" component="span">
          <PhotoCamera />
        </IconButton>
        {imageUrl && <img src={imageUrl} alt="Selected" style={{ width: '50px', height: '50px', marginLeft: '10px' }} />}
      </label>
      {errors.image && <Typography color="error">{errors.image.message}</Typography>}
      <Box mt={2}>
        <Button variant="contained" color="primary" type="submit">
          {initialTodo ? 'Update Todo' : 'Add Todo'}
        </Button>
        {initialTodo && (
          <Button variant="outlined" color="secondary" onClick={() => setEditingTodo(null)} style={{ marginLeft: '10px' }}>
            Cancel
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default TodoForm;
